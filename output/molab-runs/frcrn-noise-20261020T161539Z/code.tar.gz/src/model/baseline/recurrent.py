from __future__ import annotations

from pathlib import Path

import torch
from torch import Tensor, nn

from src.core import LoadReport

from .config import BaselineConfig
from .conv_block import conv_stack
from .panns import convert_panns_cnn10


class CRNN(nn.Module):
    def __init__(self, config: BaselineConfig) -> None:
        super().__init__()
        self.config = config
        self.blocks = conv_stack(config.channels, config.dropout)
        self.gru = nn.GRU(
            config.channels[-1],
            config.hidden,
            num_layers=config.layers,
            batch_first=True,
            bidirectional=True,
            dropout=config.dropout if config.layers > 1 else 0.0,
        )
        self.dropout = nn.Dropout(config.dropout)
        self.head = nn.Linear(2 * config.hidden, config.num_classes)

    def load_panns(self, path: str | Path) -> LoadReport:
        """Nạp 4 khối conv từ PANNs Cnn10 (cùng cấu trúc conv_stack); GRU và head giữ khởi tạo ngẫu nhiên."""
        if tuple(self.config.channels) != (64, 128, 256, 512):
            raise ValueError(f"PANNs Cnn10 weights need channels (64, 128, 256, 512), got {self.config.channels}")
        checkpoint = torch.load(path, map_location="cpu", weights_only=True)
        blocks = {key: value for key, value in convert_panns_cnn10(checkpoint).items() if key.startswith("blocks.")}
        result = self.load_state_dict(blocks, strict=False)
        missing = tuple(key for key in result.missing_keys if key.startswith("blocks."))
        report = LoadReport(missing=missing, unexpected=tuple(result.unexpected_keys))
        if not report.is_clean:
            raise ValueError(f"{path}: missing {list(report.missing[:5])}, unexpected {list(report.unexpected[:5])}")
        return report

    def classify(self, x: Tensor) -> Tensor:
        x = x.mean(dim=2).transpose(1, 2)
        x, _ = self.gru(x)
        return self.head(self.dropout(x.mean(dim=1)))

    def forward(self, x: Tensor) -> Tensor:
        return self.classify(self.blocks(x))

    def forward_stages(self, x: Tensor) -> tuple[Tensor, tuple[Tensor, ...]]:
        stages = []
        for block in self.blocks:
            x = block(x)
            stages.append(x)
        return self.classify(x), tuple(stages)


class BiLSTM(nn.Module):
    def __init__(self, config: BaselineConfig) -> None:
        super().__init__()
        self.time_pool = nn.AvgPool1d(config.time_pool)
        self.lstm = nn.LSTM(
            config.freq_bins,
            config.hidden,
            num_layers=config.layers,
            batch_first=True,
            bidirectional=True,
            dropout=config.dropout if config.layers > 1 else 0.0,
        )
        self.dropout = nn.Dropout(config.dropout)
        self.head = nn.Linear(2 * config.hidden, config.num_classes)

    def forward(self, x: Tensor) -> Tensor:
        x = self.time_pool(x.squeeze(1)).transpose(1, 2)
        x, _ = self.lstm(x)
        return self.head(self.dropout(x.mean(dim=1)))
