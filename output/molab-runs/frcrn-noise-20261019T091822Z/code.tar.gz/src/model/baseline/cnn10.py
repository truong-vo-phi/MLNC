from __future__ import annotations

from torch import Tensor, nn

from .config import BaselineConfig
from .conv_block import conv_stack


class CNN10(nn.Module):
    def __init__(self, config: BaselineConfig) -> None:
        super().__init__()
        width = config.channels[-1]
        self.blocks = conv_stack(config.channels, config.dropout)
        self.dropout = nn.Dropout(config.dropout)
        self.fc = nn.Linear(width, width)
        self.head = nn.Linear(width, config.num_classes)

    def classify(self, x: Tensor) -> Tensor:
        x = x.mean(dim=2)
        x = x.max(dim=2).values + x.mean(dim=2)
        return self.head(self.dropout(self.fc(self.dropout(x)).relu()))

    def forward(self, x: Tensor) -> Tensor:
        return self.classify(self.blocks(x))

    def forward_stages(self, x: Tensor) -> tuple[Tensor, tuple[Tensor, ...]]:
        stages = []
        for block in self.blocks:
            x = block(x)
            stages.append(x)
        return self.classify(x), tuple(stages)
